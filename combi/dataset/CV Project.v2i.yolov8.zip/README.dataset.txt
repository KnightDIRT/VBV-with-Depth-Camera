# CV Project > 2024-03-07 4:36pm
https://universe.roboflow.com/object-detection-fgjmt/cv-project-dodi2

Provided by a Roboflow user
License: CC BY 4.0

